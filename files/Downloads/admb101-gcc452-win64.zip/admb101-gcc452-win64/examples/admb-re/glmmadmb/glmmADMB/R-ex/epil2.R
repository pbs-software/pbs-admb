### Name: epil2
### Title: Seizure Counts for Epileptics
### Aliases: epil2
### Keywords: datasets

### ** Examples

data(epil2)



