Det ble rot da jeg flyttet til MI. Slettet noen filer, men de er n� lagt p� plass.
