#ifndef _XPTRDEFS_H
#define _XPTRDEFS_H
#if __GNUC__ >= 3
#pragma GCC system_header
#endif

/*--- DirectShow Reference - DirectShow Structures - TIMECODE_SAMPLE Structure */
#define ED_DEVCAP_ATN_READ 0x13B7
#define ED_DEVCAP_RTC_READ 0x13BA

#endif
