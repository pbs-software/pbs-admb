/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the w64 mingw-runtime package.
 * No warranty is given; refer to the file DISCLAIMER.PD within this package.
 */
#ifndef _ADOID_H_
#define _ADOID_H_

#include "adodef.h"
#include "adoguids.h"

#endif
